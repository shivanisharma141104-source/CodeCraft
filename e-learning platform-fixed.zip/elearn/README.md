# Coding E-Learning Platform

## ⚡ Quick Deployment (Render.com — Easiest)

1. Push this code to a GitHub repo
2. Go to [render.com](https://render.com) → New → Web Service → connect your repo
3. Set these **Environment Variables** in Render dashboard:
   - `NODE_ENV` = `production`
   - `JWT_SECRET` = any long random text (e.g. paste output of step below)
   - `GEMINI_API_KEY` = your key from [aistudio.google.com](https://aistudio.google.com/app/apikey)
4. Build Command: `npm install && npm run build`
5. Start Command: `npm start`
6. Click Deploy ✅

**Generate a JWT_SECRET:**
```
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

---

## Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `NODE_ENV` | ✅ **YES** | Must be exactly `production` |
| `JWT_SECRET` | ✅ **YES** | Long random secret for auth tokens |
| `GEMINI_API_KEY` | ✅ **YES** | Google Gemini API key for AI chat |
| `PORT` | Auto | Set automatically by most platforms |

> ⚠️ **If `NODE_ENV` is not set to `production`, the app will fail to serve correctly after deployment.** This is the #1 cause of broken deployments.

---

## Local Development

```bash
npm install
cp .env.example .env      # then fill in your values
npm run dev
```

---

## Platform-Specific Guides

### Railway
- Import repo → set env vars → deploy (uses `railway.json` automatically)

### Heroku
- Set env vars via `heroku config:set NODE_ENV=production JWT_SECRET=xxx GEMINI_API_KEY=xxx`
- Uses `Procfile` automatically

### Fly.io
```bash
fly launch
fly secrets set NODE_ENV=production JWT_SECRET=xxx GEMINI_API_KEY=xxx
fly deploy
```

---

## ⚠️ Important: Data Storage Warning

All data (users, courses, progress) is stored in `database.json` on disk. Most cloud platforms **reset this file on every redeploy**. For persistent data, migrate to PostgreSQL or Supabase.

