import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";
import { 
  User, UserRole, Course, CourseModule, VideoLesson, 
  Quiz, QuizQuestion, StudyNote, QuestionPaper, 
  ProgressTracking, Comment, CodingExercise, Notification, DailyChallenge, RegisteredInstitution
} from "../types.js";

const DB_FILE = path.join(process.cwd(), "database.json");

interface DatabaseSchema {
  users: User[];
  passwords: { [userId: string]: string };
  courses: Course[];
  modules: CourseModule[];
  lessons: VideoLesson[];
  quizzes: Quiz[];
  questions: QuizQuestion[];
  notes: StudyNote[];
  papers: QuestionPaper[];
  progress: ProgressTracking[];
  comments: Comment[];
  challenges: DailyChallenge[];
  institutions?: RegisteredInstitution[];
}

export function getYoutubeId(url: string): string {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : "";
}

// In-memory database - always available even if disk is read-only
let cachedDb: DatabaseSchema | null = null;

export function loadDb(): DatabaseSchema {
  // Return cached version if available
  if (cachedDb) return cachedDb;

  // Try to load from disk
  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, "utf-8").trim();
      
      // Guard against empty file (common on cloud deploys)
      if (content && content.length > 0) {
        const parsed = JSON.parse(content) as DatabaseSchema;
        
        // Validate it has the expected structure
        if (parsed && typeof parsed === "object" && parsed.users) {
          cachedDb = parsed;
          
          // Heal any missing keys with seed data
          const seed = getSeedData();
          const keys: (keyof DatabaseSchema)[] = [
            "users", "passwords", "courses", "modules", "lessons",
            "quizzes", "questions", "notes", "papers", "progress",
            "comments", "challenges", "institutions"
          ];
          let needsSave = false;
          for (const k of keys) {
            if (!cachedDb![k]) {
              (cachedDb as any)[k] = (seed as any)[k] || [];
              needsSave = true;
            }
          }
          if (needsSave) saveDb(cachedDb!);
          
          return cachedDb!;
        }
      }
    } catch (e) {
      console.warn("database.json could not be parsed (possibly empty or corrupted). Starting fresh with seed data.", e);
    }
  }

  // No valid DB on disk — initialize with seed data
  console.log("Initializing fresh database with seed data...");
  cachedDb = getSeedData();
  saveDb(cachedDb); // Try to persist; silently continues if disk is read-only
  return cachedDb;
}

export function saveDb(db: DatabaseSchema): void {
  cachedDb = db; // Always update in-memory cache
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (error) {
    // On read-only filesystems (many cloud platforms), writes fail silently
    // Data still lives in cachedDb for the duration of this process
    console.warn("Note: Could not persist database.json to disk. Data is stored in memory only (will reset on restart). Consider using a real database for production.", error);
  }
}

function getSeedData(): DatabaseSchema {
  const salt = bcrypt.genSaltSync(10);
  
  const users: User[] = [
    {
      id: "u-admin",
      email: "admin@codecraft.com",
      name: "Admin Principal",
      role: UserRole.ADMIN,
      approved: true,
      avatar: "https://api.dicebear.com/7.x/pixel-art/svg?seed=admin",
      createdAt: new Date().toISOString()
    },
    {
      id: "u-inst1",
      email: "dr_alan@codecraft.com",
      name: "Dr. Alan Turing",
      role: UserRole.INSTRUCTOR,
      approved: true,
      avatar: "https://api.dicebear.com/7.x/pixel-art/svg?seed=alan",
      createdAt: new Date().toISOString(),
      isAcademicAffiliated: true,
      institutionId: "inst-2",
      institutionName: "Massachusetts Institute of Technology (MIT)"
    },
    {
      id: "u-inst2",
      email: "grace@codecraft.com",
      name: "Grace Hopper",
      role: UserRole.INSTRUCTOR,
      approved: false,
      avatar: "https://api.dicebear.com/7.x/pixel-art/svg?seed=grace",
      createdAt: new Date().toISOString()
    },
    {
      id: "u-stud1",
      email: "student@codecraft.com",
      name: "John Doe",
      role: UserRole.STUDENT,
      approved: true,
      avatar: "https://api.dicebear.com/7.x/pixel-art/svg?seed=john",
      createdAt: new Date().toISOString(),
      isAcademicAffiliated: true,
      institutionId: "inst-2",
      institutionName: "Massachusetts Institute of Technology (MIT)"
    }
  ];

  const passwords: { [id: string]: string } = {
    "u-admin": bcrypt.hashSync("admin123", salt),
    "u-inst1": bcrypt.hashSync("instructor123", salt),
    "u-inst2": bcrypt.hashSync("instructor123", salt),
    "u-stud1": bcrypt.hashSync("student123", salt)
  };

  const courses: Course[] = [
    {
      id: "c-python",
      title: "Python Masterclass: From Beginner to Pro",
      description: "Dive deep into modern Python programming. Master variables, lists, OOP, APIs, and data science concepts with hands-on coding exercises.",
      category: "Python",
      duration: "10 hours",
      difficulty: "Beginner",
      thumbnail: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=600&auto=format&fit=crop&q=60",
      instructorId: "u-inst1",
      authorName: "Dr. Alan Turing",
      createdAt: new Date().toISOString()
    },
    {
      id: "c-java",
      title: "Java Foundations: OOP & Data Structures",
      description: "Understand compilation, JVM, typed lists, interfaces, concurrency, and algorithms using core Java. Essential for university examinations.",
      category: "Java",
      duration: "15 hours",
      difficulty: "Intermediate",
      thumbnail: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&auto=format&fit=crop&q=60",
      instructorId: "u-inst1",
      authorName: "Dr. Alan Turing",
      createdAt: new Date().toISOString()
    },
    {
      id: "c-js",
      title: "Javascript Essentials for Web Apps",
      description: "Unlock high-performance client-side Javascript. Master ES6+, closures, Async/Await, Fetch API, and asynchronous events.",
      category: "JavaScript",
      duration: "8 hours",
      difficulty: "Beginner",
      thumbnail: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=600&auto=format&fit=crop&q=60",
      instructorId: "u-inst1",
      authorName: "Dr. Alan Turing",
      createdAt: new Date().toISOString()
    },
    {
      id: "c-react",
      title: "React.js: Complete Single Page App Guide",
      description: "Build robust, blazing-fast web architectures. Learn JSX, State, Hooks, Context API, Tailwind integration, and responsive layout designs.",
      category: "React.js",
      duration: "12 hours",
      difficulty: "Intermediate",
      thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=600&auto=format&fit=crop&q=60",
      instructorId: "u-inst1",
      authorName: "Dr. Alan Turing",
      createdAt: new Date().toISOString()
    }
  ];

  const modules: CourseModule[] = [
    { id: "m-py-1", courseId: "c-python", title: "Variables & Standard I/O", orderIndex: 1 },
    { id: "m-py-2", courseId: "c-python", title: "Data Structures & Control Flows", orderIndex: 2 },
    { id: "m-py-3", courseId: "c-python", title: "Object Oriented Programming (OOP)", orderIndex: 3 },
    { id: "m-jv-1", courseId: "c-java", title: "Java Intro & JVM Architecture", orderIndex: 1 },
    { id: "m-jv-2", courseId: "c-java", title: "Classes, Objects & Inheritance", orderIndex: 2 },
    { id: "m-js-1", courseId: "c-js", title: "ES6 Syntax & Array Iterators", orderIndex: 1 },
    { id: "m-js-2", courseId: "c-js", title: "Promises & Async/Await Pattern", orderIndex: 2 }
  ];

  const lessons: VideoLesson[] = [
    {
      id: "l-py-1", moduleId: "m-py-1", courseId: "c-python",
      title: "Setting Up Python & Variables",
      videoUrl: "https://www.youtube.com/watch?v=kqtD5dpn9C8",
      youtubeId: "kqtD5dpn9C8", orderIndex: 1, duration: "10 mins",
      notesName: "Python_Installation_Guide.pdf", notesUrl: "/api/downloads/python_setup.pdf",
      sourceCode: `print("Welcome to Python!")\nusername = "Ciel"\nprint("Hello,", username)`,
      sourceCodeUrl: "/api/downloads/py-v1.py"
    },
    {
      id: "l-py-2", moduleId: "m-py-1", courseId: "c-python",
      title: "Input Functions & Typings",
      videoUrl: "https://www.youtube.com/watch?v=kqtD5dpn9C8",
      youtubeId: "kqtD5dpn9C8", orderIndex: 2, duration: "15 mins",
      notesName: "Console_IO.doc", notesUrl: "/api/downloads/py_io.doc",
      sourceCode: `name = input("Enter name: ")\nprint("Greetings", name)`
    },
    {
      id: "l-py-3", moduleId: "m-py-2", courseId: "c-python",
      title: "Python Lists & Comprehensions",
      videoUrl: "https://www.youtube.com/watch?v=9OeznAkyQz4",
      youtubeId: "9OeznAkyQz4", orderIndex: 1, duration: "18 mins",
      notesName: "Lists_CheatSheet.pdf", notesUrl: "/api/downloads/py_lists.pdf",
      sourceCode: `numbers = [1, 2, 3, 4, 5]\nsquares = [x**2 for x in numbers]\nprint("Squares:", squares)`
    },
    {
      id: "l-jv-1", moduleId: "m-jv-1", courseId: "c-java",
      title: "Understanding JDK, JRE, & JVM",
      videoUrl: "https://www.youtube.com/watch?v=eIrMbAQSU34",
      youtubeId: "eIrMbAQSU34", orderIndex: 1, duration: "20 mins",
      notesName: "Java_Architecture.pdf", notesUrl: "/api/downloads/java_jvm.pdf",
      sourceCode: `public class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello from JVM!");\n    }\n}`
    },
    {
      id: "l-js-1", moduleId: "m-js-1", courseId: "c-js",
      title: "Arrow Functions & Let/Const Scope",
      videoUrl: "https://www.youtube.com/watch?v=W6NZfCO5SIk",
      youtubeId: "W6NZfCO5SIk", orderIndex: 1, duration: "12 mins",
      notesName: "ES6_Scope_Variables.ppt", notesUrl: "/api/downloads/es6_scope.ppt",
      sourceCode: "const greet = (name) => `Hi ${name}!`;\nconsole.log(greet(\"Developer\"));"
    },
    {
      id: "l-js-2", moduleId: "m-js-2", courseId: "c-js",
      title: "Understanding Promises & Microtasks",
      videoUrl: "https://www.youtube.com/watch?v=vV_Wb0bS8_g",
      youtubeId: "vV_Wb0bS8_g", orderIndex: 1, duration: "25 mins",
      notesName: "Promises_Handout.pdf", notesUrl: "/api/downloads/js_promises.pdf",
      sourceCode: `const delay = (ms) => new Promise(res => setTimeout(res, ms));\ndelay(1000).then(() => console.log("Promise Resolved!"));`
    }
  ];

  const quizzes: Quiz[] = [
    { id: "q-py-1", courseId: "c-python", title: "Variables & Input Quiz", durationMinutes: 10 },
    { id: "q-js-1", courseId: "c-js", title: "Arrow Functions Quiz", durationMinutes: 5 }
  ];

  const questions: QuizQuestion[] = [
    {
      id: "qq-py-1", quizId: "q-py-1",
      questionText: "Which statement is true to output 'Hello' in Python?",
      options: ["console.log('Hello')", "print('Hello')", "System.out.println('Hello')", "cout << 'Hello';"],
      correctAnswerIndex: 1,
      explanation: "Python uses the print() function to write output to the standard output terminal."
    },
    {
      id: "qq-py-2", quizId: "q-py-1",
      questionText: "How do you declare a variable called 'x' with the integer value 5 in Python?",
      options: ["int x = 5", "var x = 5", "x = 5", "let x: 5"],
      correctAnswerIndex: 2,
      explanation: "Python is dynamically typed; no keywords or type declarations are needed."
    },
    {
      id: "qq-js-1", quizId: "q-js-1",
      questionText: "What is the primary difference between 'let' and 'var' declarations in JS?",
      options: ["'let' is block-scoped, while 'var' is function-scoped", "'var' cannot be updated", "'let' is pushed to the global window always", "There is no difference"],
      correctAnswerIndex: 0,
      explanation: "Variables declared with 'let' are block-scoped. 'var' variables are function-scoped."
    }
  ];

  const notes: StudyNote[] = [
    {
      id: "n-py", title: "Python OOP and Magic Methods Cheat Sheet", category: "Python",
      content: "# Python OOP\n\nClass syntax and magic methods reference.",
      downloadsCount: 145, fileName: "Python_OOP_Cheatsheet.pdf",
      fileUrl: "/api/downloads/py_oop.pdf", fileType: "pdf"
    },
    {
      id: "n-js", title: "JavaScript ES6+ Array Iterators Guide", category: "JavaScript",
      content: "# JS Array Iterators\n\nMap, filter, and reduce guide.",
      downloadsCount: 228, fileName: "JS_Iterator_Map_Filter.pdf",
      fileUrl: "/api/downloads/js_map_filter.pdf", fileType: "pdf"
    }
  ];

  const papers: QuestionPaper[] = [
    {
      id: "qp-py", title: "2025 Python Advanced Final Term Examination Paper",
      category: "Python", year: 2025, examType: "Previous Year",
      fileUrl: "/api/downloads/qp_py_2025.pdf",
      content: "### Python Exam\n\nQ1: Implement a @timer decorator.\n\nQ2: Explain generator functions with yield.",
      answerKeys: { "Q1": "Nested wrapper function measuring time.time().", "Q2": "Generators use yield to lazily produce values." }
    },
    {
      id: "qp-ds", title: "Data Structures & Algorithms MCQ Question Bank",
      category: "Data Structures & Algorithms", year: 2024, examType: "MCQ Bank",
      fileUrl: "/api/downloads/qp_dsa.pdf",
      content: "### DSA Bank\n\nQ1: Binary Search complexity? B) O(log N)\n\nQ2: LIFO structure? C) Stack",
      answerKeys: { "Q1": "B", "Q2": "C" }
    }
  ];

  const challenges: DailyChallenge[] = [
    {
      id: "chal-1", title: "Two Sum Problem",
      description: "Write a function that returns indices of two numbers that add up to a target.",
      problem: "Given an array nums and integer target, return indices of the two numbers that add up to target.",
      category: "Data Structures & Algorithms",
      startingCode: "function twoSum(nums, target) {\n  // Write your code here\n  return [];\n}",
      solutionCode: "function twoSum(nums, target) {\n  const map = new Map();\n  for (let i = 0; i < nums.length; i++) {\n    const complement = target - nums[i];\n    if (map.has(complement)) return [map.get(complement), i];\n    map.set(nums[i], i);\n  }\n  return [];\n}",
      testCases: [
        { input: "[[2, 7, 11, 15], 9]", expectedOutput: "[0, 1]" },
        { input: "[[3, 2, 4], 6]", expectedOutput: "[1, 2]" }
      ],
      date: new Date().toISOString().split("T")[0]
    }
  ];

  const institutions: RegisteredInstitution[] = [
    {
      id: "inst-1", name: "Model Academy Secondary School",
      type: "school", category: "academic", location: "Jammu, India",
      website: "https://www.modelacademy.in", contactEmail: "info@modelacademy.in",
      contactPhone: "+91-191-2543322", enrollmentSize: 1200,
      description: "A prestigious school known for early computer science training.",
      createdAt: new Date().toISOString(), status: "approved"
    },
    {
      id: "inst-2", name: "Massachusetts Institute of Technology (MIT)",
      type: "university", category: "academic", location: "Boston, USA",
      website: "https://www.mit.edu", contactEmail: "admissions@mit.edu",
      contactPhone: "+1-617-253-1000", enrollmentSize: 11000,
      description: "World-renowned research university in AI, algorithms and software.",
      createdAt: new Date().toISOString(), status: "approved"
    },
    {
      id: "inst-3", name: "Indian Institute of Technology (IIT Delhi)",
      type: "college", category: "academic", location: "New Delhi, India",
      website: "https://home.iitd.ac.in", contactEmail: "registrar@iitd.ac.in",
      contactPhone: "+91-11-2659-1000", enrollmentSize: 8500,
      description: "Top-tier engineering university in computer science theory and OOP.",
      createdAt: new Date().toISOString(), status: "approved"
    }
  ];

  return {
    users, passwords, courses, modules, lessons,
    quizzes, questions, notes, papers,
    progress: [], comments: [
      {
        id: "c1", lessonId: "l-py-1", userId: "u-stud1",
        userName: "John Doe", userRole: UserRole.STUDENT,
        text: "This explanation is brilliant! Simple setup instructions made coding easy. Thanks",
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
      }
    ],
    challenges, institutions
  };
}
